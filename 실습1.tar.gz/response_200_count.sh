#!/bin/bash

# v1
#result=0

#while read line
#do
#  response=$(awk -F " " '{print $9}' <<< $(echo $line))
#  if [ $response == "200" ]
#  then
#    echo $line >> response_200.log
#    result=$(($result+1))
#  fi
#done <<< $(tail -100 access.log )

#echo $result

# v2
tail -100 access.log | grep -w 'HTTP/1.[01]" 200' | tee response_200.log | grep -c 'HTTP/1.[01]" 200'
