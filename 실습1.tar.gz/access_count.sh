#!/bin/bash

# v1
#result=0

#while read line
#do
#  ip=$(awk -F " " '{print $1}' <<< $(echo $line))
#  if [ $ip == "130.237.218.86" ]
#  then
#    result=$(($result+1))
#  fi
#done < access.log 

#echo $result

# v2
cut -d " " -f1 access.log | grep -c 130.237.218.86
